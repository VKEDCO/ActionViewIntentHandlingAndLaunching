package org.vkedco.mobicom.android.action_view_intent_handler;

/*
 **********************************************************
 * ActionViewIntentHandlerAct is the activity
 * class that registers itself through its intent-filter
 * in AndroidManifest.xml as a handler of 
 * android.intent.action.VIEW. 
 * 
 * bugs to vladimir dot kulyukin at gmail dot com
 **********************************************************
 */

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class ActionViewIntentHandlerAct extends Activity {
	static final private int WIKI_DIALOG = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_action_view_intent_handler);
		// This has been depricated for API 13 and up where
		// fragments should be used instead. But it does work on 4.2 
		// and 2.3+
		this.showDialog(WIKI_DIALOG);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_action_view_intent_handler,
				menu);
		return true;
	}
	
	// this handler is called when showDialog() is called.
    // this handler creates a dialog on demand.
    // after the initial creation, whenever showDialog() is
    // called onPrepareDialog() is called.
    public Dialog onCreateDialog(int id) {
    	switch(id) {
    	case (WIKI_DIALOG): 
    		LayoutInflater li = LayoutInflater.from(this);
    		View wikiView = li.inflate(R.layout.link_details, null);
    		AlertDialog.Builder wikiLinkDialog = new AlertDialog.Builder(this);
    		
    		wikiLinkDialog.setTitle(getResources().getString(R.string.kurt_godel_name));
    		wikiLinkDialog.setView(wikiView);
    		return wikiLinkDialog.create();
    	}
    	return null;
    }
    
    // onPrepareDialog should be overriden if the dialog will
    // be different every time showDialog() is called.
    public void onPrepareDialog(int id, Dialog dialog) {
    	switch (id) {
    	case (WIKI_DIALOG):
    		String wikiText = "Wikipedia article on " +
    			getResources().getString(R.string.kurt_godel_name) +
    			"\n is at " + getResources().getString(R.string.kurt_godel_wiki_link)
    			+ "\n";
    		AlertDialog wikiDialog = (AlertDialog)dialog;
    		TextView tv = (TextView)wikiDialog.findViewById(R.id.link_details_text);
    		tv.setText(wikiText);
    		break;
    	}
    }

}
