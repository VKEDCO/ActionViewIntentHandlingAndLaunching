/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.mobicom.android.action_view_intent_launcher;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}