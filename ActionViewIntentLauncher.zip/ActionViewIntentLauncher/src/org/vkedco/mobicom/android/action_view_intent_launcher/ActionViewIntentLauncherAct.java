package org.vkedco.mobicom.android.action_view_intent_launcher;

/*
 *************************************************
 * ActionViewIntentLauncherAct is the activity
 * that launches a browser intent, which, if
 * ActionViewIntentHandler is installed, causes
 * it to be added to the list of ACTION.VIEW handlers 
 * that the user is asked to choose from.
 * 
 * bugs, comments to vladimir dot kulyukin at 
 * usu dot edu
 ************************************************* 
 */

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;

public class ActionViewIntentLauncherAct extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Intent myIntent = new Intent(Intent.ACTION_VIEW,
        		Uri.parse(getResources().getString(R.string.kurt_godel_wiki_url)));
        
        this.startActivity(myIntent);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

}
